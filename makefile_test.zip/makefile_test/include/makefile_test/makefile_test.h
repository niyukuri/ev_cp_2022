#pragma once

#include <string>

void hello(const std::string &msg);
