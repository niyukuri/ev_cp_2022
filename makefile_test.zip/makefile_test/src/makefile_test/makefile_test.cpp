#include "makefile_test/makefile_test.h"
#include <iostream>

void hello(const std::string &msg) {
  std::cout << "Hello, " << msg << "!" << std::endl;
}
